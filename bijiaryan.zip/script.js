
document.addEventListener('DOMContentLoaded', () => {

    window.addEventListener('scroll', () => {
        const winScroll = window.scrollY || document.documentElement.scrollTop;
        const height = document.documentElement.scrollHeight - window.innerHeight;
        const scrolled = (winScroll / height) * 100;

        // Progress Bar di bagian atas
        const progressBar = document.getElementById("top-progress-bar");
        if(progressBar) progressBar.style.width = scrolled + "%";

        // Navbar Scroll Effect
        const nav = document.getElementById('navbar');
        if (winScroll > 50) nav.classList.add('scrolled');
        else nav.classList.remove('scrolled');

        // Reveal Animation (Staggered / Bergantian)
        document.querySelectorAll('.reveal').forEach((el, index) => {
            const rect = el.getBoundingClientRect();
            if (rect.top < window.innerHeight - 100) {
                setTimeout(() => {
                    el.classList.add('active');
                }, (index % 3) * 100); 
            }
        });

        const hero = document.getElementById('hero');
        if (hero) {
            const darkness = Math.min(0.7 + (winScroll / 1200), 0.95); 
            hero.style.backgroundImage = `linear-gradient(rgba(0,0,0,${darkness}), rgba(0,0,0,${darkness})), url('vermi1.png')`;
            
            hero.style.backgroundPosition = `center ${winScroll * 0.1}px`;
        }
    }, { passive: true });

    document.querySelectorAll('.accordion-header').forEach(header => {
        header.addEventListener('click', () => {
            const body = header.nextElementSibling;
            const icon = header.querySelector('i');
            
            // Tutup accordion lain yang sedang terbuka
            document.querySelectorAll('.accordion-body').forEach(b => {
                if(b !== body && b.classList.contains('active')) {
                    b.classList.remove('active');
                    const otherIcon = b.previousElementSibling.querySelector('i');
                    if(otherIcon) otherIcon.classList.replace('fa-chevron-up', 'fa-chevron-down');
                }
            });

            body.classList.toggle('active');
            if(body.classList.contains('active')) {
                icon.classList.replace('fa-chevron-down', 'fa-chevron-up');
            } else {
                icon.classList.replace('fa-chevron-up', 'fa-chevron-down');
            }
        });
    });

    const slides = document.querySelectorAll('.info-slide');
    const dotsContainer = document.getElementById('sliderDots');
    let currentSlide = 0;

    if(slides.length > 0) {
        slides.forEach((_, i) => {
            const dot = document.createElement('div');
            dot.classList.add('dot');
            if (i === 0) dot.classList.add('active');
            dot.addEventListener('click', () => goToSlide(i));
            if(dotsContainer) dotsContainer.appendChild(dot);
        });

        function goToSlide(index) {
            slides[currentSlide].classList.remove('active');
            const dots = document.querySelectorAll('.dot');
            if(dots[currentSlide]) dots[currentSlide].classList.remove('active');
            
            currentSlide = index;
            
            slides[currentSlide].classList.add('active');
            if(dots[currentSlide]) dots[currentSlide].classList.add('active');
        }

        slides.forEach(slide => {
            slide.addEventListener('click', () => {
                const link = slide.getAttribute('data-link');
                if(link) window.location.href = link;
            });
        });

        setInterval(() => {
            goToSlide((currentSlide + 1) % slides.length);
        }, 5000);
    }

    const newsItems = document.querySelectorAll('.news-card');
    const itemsPerPage = 5; 
    const paginationControls = document.getElementById('paginationControls');
    let currentPage = 1;

    function showPage(pageNumber) {
        const pageCount = Math.ceil(newsItems.length / itemsPerPage);
        
        if (pageNumber < 1) pageNumber = 1;
        if (pageNumber > pageCount) pageNumber = pageCount;
        
        currentPage = pageNumber;
        const start = (pageNumber - 1) * itemsPerPage;
        const end = start + itemsPerPage;

        newsItems.forEach((item, index) => {
            item.classList.remove('visible');
            item.style.display = "none"; // Hilangkan total agar tidak makan space
            
            if (index >= start && index < end) {
                item.style.display = "flex";
                setTimeout(() => item.classList.add('visible'), 50);
            }
        });

        renderPaginationControls(pageCount);
        
        // Scroll ke atas section news jika bukan load pertama
        if(pageNumber > 1 || window.scrollY > 1000) {
            const section = document.getElementById('activities');
            if(section) section.scrollIntoView({behavior: 'smooth'});
        }
    }

    function renderPaginationControls(pageCount) {
        if (!paginationControls) return;
        paginationControls.innerHTML = '';

        const createBtn = (label, target, isActive = false, isDisabled = false) => {
            const btn = document.createElement('button');
            btn.classList.add('page-btn');
            if (isActive) btn.classList.add('active');
            if (isDisabled) {
                btn.classList.add('disabled');
                btn.disabled = true;
            }
            btn.innerText = label;
            btn.onclick = () => showPage(target);
            return btn;
        };

        paginationControls.appendChild(createBtn('<<<', 1, false, currentPage === 1));
        paginationControls.appendChild(createBtn('<', currentPage - 1, false, currentPage === 1));

        for (let i = 1; i <= pageCount; i++) {
            if (i === 1 || i === pageCount || (i >= currentPage - 1 && i <= currentPage + 1)) {
                paginationControls.appendChild(createBtn(i, i, i === currentPage));
            } 
            else if (i === currentPage - 2 || i === currentPage + 2) {
                const dots = document.createElement('span');
                dots.innerText = '..';
                dots.style.color = "#555";
                dots.style.margin = "0 8px";
                paginationControls.appendChild(dots);
            }
        }

        paginationControls.appendChild(createBtn('>', currentPage + 1, false, currentPage === pageCount));
        paginationControls.appendChild(createBtn('>>>', pageCount, false, currentPage === pageCount));
    }

    if (newsItems.length > 0) {
        showPage(1);
    }

    async function updateServerStatus() {
        const ip = "plus-2.arqonara.com:25004";
        const statusEl = document.getElementById('srv-status');
        const playerEl = document.getElementById('player-count');
        const tpsEl = document.getElementById('tps-val');

        try {
            const response = await fetch(`https://api.mcsrvstat.us/2/${ip}`);
            const data = await response.json();
            
            if (data.online) {
                if(statusEl) { statusEl.innerText = "ONLINE"; statusEl.style.color = "#00ff00"; }
                if(playerEl) playerEl.innerText = data.players.online;
                // TPS Simulasi Realistic (karena API publik tidak kirim TPS asli)
                if(tpsEl) tpsEl.innerText = (19.6 + Math.random() * 0.4).toFixed(1);
            } else {
                if(statusEl) { statusEl.innerText = "OFFLINE"; statusEl.style.color = "#ff0000"; }
                if(playerEl) playerEl.innerText = "0";
                if(tpsEl) tpsEl.innerText = "0.0";
            }
        } catch (e) {
            console.warn("Server API Timeout");
        }
    }

    updateServerStatus();
    setInterval(updateServerStatus, 60000); 
});